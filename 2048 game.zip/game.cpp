#include "game.hpp"
#include "board.hpp"

QBrush brush0(QColor(202, 192, 180));
QBrush brush1(QColor(237, 228, 219));
QBrush brush2(QColor(235, 222, 199));
QBrush brush3(QColor(233, 178, 128));
QBrush brush4(QColor(245, 149, 99));
QBrush brush5(QColor(230, 132, 105));
QBrush brush6(QColor(228, 107, 76));
QBrush brush7(QColor(234, 207, 115));
QBrush brush8(QColor(237, 204, 98));
QBrush brush9(QColor(237, 200, 80));
QBrush brush10(QColor(237, 197, 63));
QBrush brush11(QColor(237, 194, 45));
QBrush brush12(QColor(29, 90, 254));
QPen pen(Qt::black);

QList<QBrush> brush = {
    brush0,
    brush1,
    brush2,
    brush3,
    brush4,
    brush5,
    brush6,
    brush7,
    brush8,
    brush9,
    brush10,
    brush11,
    brush12
};

QFont font1;

std::map<int, int> map;

Game::Game(QWidget *parent): QGraphicsView(parent) {
    scene = new QGraphicsScene(0, 0, 800, 600);
    setScene(scene);
}

void Game::start() {

    map.insert(std::pair<int, int>(0, 0));
    for (int i = 1; i < 13; i++) {
        map.insert(std::pair<int, int>((int)std::pow(2, i), i));
    }

    map.insert(std::pair<int, int>(0, 0));
    map.insert(std::pair<int, int>(2, 1));
    map.insert(std::pair<int, int>(4, 2));
    map.insert(std::pair<int, int>(8, 3));

    font1.setBold(true);
    font1.setPixelSize(15);


    board = new Board();

    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE ; j++) {

            QGraphicsRectItem* rect = scene->addRect(100*i, 100*j, 90, 90, pen, brush0);
            qboard.append(rect);

            QGraphicsTextItem* text = scene->addText("",font1);

            text->setX(100*i + 45);
            text->setY(100*j + 45);

            qtext.append(text);
        }
    }
    updateBoard();
}

void Game::keyPressEvent(QKeyEvent* event) {

    if (event->key() == Qt::Key_Up) {
        std::cout << "Hello" << std::endl;
        board->upUpdate();
    } else if (event->key() == Qt::Key_Down) {
        board->downUpdate();
    } else if (event->key() == Qt::Key_Right) {
        board->rightUpdate();
    } else if (event->key() == Qt::Key_Left) {
        board->leftUpdate();
    }
    board->showBoard();
    std::cout << std::endl;
    updateBoard();
}

void Game::clearText() {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE ; j++) {
            qtext[j * SIZE + i]->setPlainText("");
        }
    }
}
void Game::updateBoard() {
    clearText();
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE ; j++) {
            int value = board->tiles[i][j];
            // std::cout << "value" << value << "i" << map[value] <<std::endl;
            qboard[j * SIZE + i]->setBrush(brush[map[value]]);
            // qtext[j * SIZE + i]->setPlainText(QString::number(value));
            if (value != 0) {
                std::cout << value << std::endl;
                qtext[j * SIZE + i]->setPlainText(QString::number(value));
            }
        }
    }
}
