#include <QApplication>
#include "game.hpp"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Game *game;
    game = new Game();
    game->show();
    game->start();

    return a.exec();
}
