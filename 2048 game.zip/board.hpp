#ifndef BOARD_HPP
#define BOARD_HPP

#include <iostream>
#include <cstdlib>
#include <random>
#include <list>
#include <iterator>

#include <QGraphicsItem>
#include <QKeyEvent>
#include <QList>

#define SIZE 4

int init_board();

class Board {

    public:

        int size;
        int** tiles;

        Board();

        void showBoard() const;

        void sumTiles(int i1, int j1, int i2, int j2);
        void moveTile(int i1, int j1, int i2, int j2);
        void clearTile(int i, int j);

        int addTile();
        bool TileIn(int i, int j);
        int numTilesInBoard();
        
        int moveTileLeft(int i, int j, int* walls);
        int moveTileRight(int i, int j, int* walls);
        int moveTileUp(int i, int j, int* walls);
        int moveTileDown(int i, int j, int* walls);

        void leftUpdate();
        void rightUpdate();
        void upUpdate();
        void downUpdate();

};

#endif
