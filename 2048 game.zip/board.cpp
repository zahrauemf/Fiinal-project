#include "board.hpp"


using namespace std;

Board::Board() {

    tiles = new int*[SIZE];
    for (int i = 0; i < SIZE; i++) {
        tiles[i] = new int[SIZE];
        for (int j = 0; j < SIZE; j++) {
            tiles[i][j] = 0;
        };
    };

    addTile();
    addTile();

};

void Board::clearTile(int i, int j) {
    tiles[i][j] = 0;
}

void Board::sumTiles(int i1, int j1, int i2, int j2) {
    tiles[i2][j2] *= 2;
    clearTile(i1, j1);
}

void Board::moveTile(int i1, int j1, int i2, int j2) {
    tiles[i2][j2] = tiles[i1][j1];
    clearTile(i1, j1);
}
int Board::moveTileLeft(int i, int j, int* walls) {

    int prev_value = tiles[i][j];
    int new_j = walls[i];
    int cur_value = tiles[i][new_j];
    int adj_j = new_j + 1;

    if (TileIn(i, new_j)) {
        walls[i] ++;
        if (prev_value == cur_value) {
            sumTiles(i, j, i, new_j);
            return 1;
        } else {
            if (adj_j == j) {
                return 0;
            } else {
                moveTile(i, j, i, adj_j);
                return 1;
            }
        }
    } else {
        moveTile(i, j, i, new_j);
        return 1;
    }
}
int Board::moveTileRight(int i, int j, int* walls) {

    int prev_value = tiles[i][j];
    int new_j = walls[i];
    int cur_value = tiles[i][new_j];
    int adj_j = new_j - 1;

    if (TileIn(i, new_j)) {
        walls[i] --;
        if (prev_value == cur_value) {
            sumTiles(i, j, i, new_j);
            return 1;
        } else {
            if (adj_j == j) {
                return 0;
            } else {
                moveTile(i, j, i, adj_j);
                return 1;
            }
        }
    } else {
        moveTile(i, j, i, new_j);
        return 1;
    }
}
int Board::moveTileUp(int i, int j, int* walls) {

    int prev_value = tiles[i][j];
    int new_i = walls[j];
    int cur_value = tiles[new_i][j];
    int adj_i = new_i + 1;

    if (TileIn(new_i, j)) {
        walls[j] ++;
        if (prev_value == cur_value) {
            sumTiles(i, j, new_i, j);
            return 1;
        } else {
            if (adj_i == i) {
                return 0;
            } else {
                moveTile(i, j, adj_i, j);
                return 1;
            }
        }
    } else {
        moveTile(i, j, new_i, j);
        return 1;
    }
}

int Board::moveTileDown(int i, int j, int* walls) {

    int prev_value = tiles[i][j];
    int new_i = walls[j];
    int cur_value = tiles[new_i][j];
    int adj_i = new_i - 1;

    if (TileIn(new_i, j)) {
        walls[j] --;
        if (prev_value == cur_value) {
            sumTiles(i, j, new_i, j);
            return 1;
        } else {
            if (adj_i == i) {
                return 0;
            } else {
                moveTile(i, j, adj_i, j);
                return 1;
            }
        }
    } else {
        moveTile(i, j, new_i, j);
        return 1;
    }
}

void Board::leftUpdate() {

    int walls[SIZE];

    for (int k = 0; k < SIZE; k++) {
        walls[k] = 0;
    };

    int moved = false;
    for (int j = 1; j < SIZE; j++) {
        for (int i = 0; i < SIZE; i++) {
            if (TileIn(i, j)) {
                // cout << i << " " << j << endl;
                int cur_move = moveTileLeft(i, j, walls);
                moved = moved || cur_move;
            }
            
        }
    };
    if (moved == true) {
        addTile();
    }
}

void Board::rightUpdate() {

    int walls[SIZE];

    for (int k = 0; k < SIZE; k++) {
        walls[k] = SIZE - 1;
    };

    int moved = false;
    for (int j = SIZE - 2; j > -1; j--) {
        for (int i = 0; i < SIZE; i++) {
            if (TileIn(i, j)) {
                // cout << i << " " << j << endl;
                int cur_move = moveTileRight(i, j, walls);
                moved = moved || cur_move;
            }
            
        }
    };
    if (moved == true) {
        addTile();
    }

}

void Board::upUpdate() {
    int walls[SIZE];

    for (int k = 0; k < SIZE; k++) {
        walls[k] = 0;
    };

    int moved = false;
    for (int i = 1; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (TileIn(i, j)) {
                // cout << i << " " << j << endl;
                int cur_move = moveTileUp(i, j, walls);
                moved = moved || cur_move;
            }
            
        }
    };
    if (moved == true) {
        addTile();
    }
}

void Board::downUpdate() {

    int walls[SIZE];

    for (int k = 0; k < SIZE; k++) {
        walls[k] = SIZE - 1;
    };

    int moved = false;
    for (int i = SIZE - 2; i > -1; i--) {
        for (int j = 0; j < SIZE; j++) {
            if (TileIn(i, j)) {
                // cout << i << " " << j << endl;
                int cur_move = moveTileDown(i, j, walls);
                moved = moved || cur_move;
            }
            
        }
    };
    if (moved == true) {
        addTile();
    }
}

void Board::showBoard() const {

    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            cout << tiles[i][j];
            cout << "     ";
        };
        cout << endl; 
    };
};

bool Board::TileIn(int i, int j) {
    if (tiles[i][j] != 0) {
        return true;
    }
    return false;
}

int Board::numTilesInBoard() {
    int k = 0;
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (TileIn(i, j)) {
                k++;
            }
        };
    };
    return k;
}

int Board::addTile() {

    int a = (int) ( (float)rand() * 10 / RAND_MAX );   

    // cout << a << endl;

    if (a > 0) {
        a = 2;
    } else {
        a = 4;
    }

    if (numTilesInBoard() == SIZE * SIZE) {
        return 0;
    }


    int ai = (int) ( (float)rand() * SIZE / RAND_MAX );
    int aj = (int) ( (float)rand() * SIZE / RAND_MAX );

    while (TileIn(ai, aj)) {
        ai = (int) ( (float)rand() * SIZE / RAND_MAX );
        aj = (int) ( (float)rand() * SIZE / RAND_MAX );
    }

    tiles[ai][aj] = a;

    return 1;


}



