#ifndef GAME_HPP
#define GAME_HPP

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QWidget>
#include <QList>
#include <QGraphicsRectItem>
#include <iostream>
#include <QBrush>
#include <QPen>
#include <QPainter>
#include <QColor>
#include <list>
#include <map>
#include <cmath>
#include <QFont>
#include <QString>

#include "board.hpp"

class Game: public QGraphicsView {
public:

    Game(QWidget* parent=NULL);

    void start();

    QGraphicsScene* scene;

    Board* board;
    QList<QGraphicsRectItem*> qboard;
    QList<QGraphicsTextItem*> qtext;

    void keyPressEvent(QKeyEvent* event);
    void updateBoard();
    void clearText();

private:

};

#endif
